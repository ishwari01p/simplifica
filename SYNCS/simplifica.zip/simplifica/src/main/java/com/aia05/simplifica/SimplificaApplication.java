package com.aia05.simplifica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplificaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplificaApplication.class, args);
	}

}
