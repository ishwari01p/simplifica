package com.aia05.simplifica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplificaApplicationTests {

	@Test
	void contextLoads() {
	}

}
